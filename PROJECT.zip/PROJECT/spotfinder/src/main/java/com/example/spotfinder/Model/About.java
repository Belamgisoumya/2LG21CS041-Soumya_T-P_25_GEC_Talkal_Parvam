package com.example.spotfinder.Model;

public class About {
    
}

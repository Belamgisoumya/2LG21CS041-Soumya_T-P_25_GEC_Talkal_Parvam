package com.example.spotfinder.Model;

public class Home {
    
}

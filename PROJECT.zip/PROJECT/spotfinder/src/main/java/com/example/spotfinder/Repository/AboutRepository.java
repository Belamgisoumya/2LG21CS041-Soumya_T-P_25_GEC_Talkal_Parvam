package com.example.spotfinder.Repository;

public class AboutRepository {
    
}

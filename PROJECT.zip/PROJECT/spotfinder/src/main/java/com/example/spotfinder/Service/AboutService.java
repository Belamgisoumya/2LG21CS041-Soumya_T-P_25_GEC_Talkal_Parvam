package com.example.spotfinder.Service;

public class AboutService {
    
}

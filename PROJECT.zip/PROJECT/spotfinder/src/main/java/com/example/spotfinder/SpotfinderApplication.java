package com.example.spotfinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpotfinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpotfinderApplication.class, args);
	}

}
